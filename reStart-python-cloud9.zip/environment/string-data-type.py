myString = "This is a string"
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firststring = "water"
secondstring = "falls"
thirdstring = firststring + secondstring
print(thirdstring)
name = input("what is your name?")
print(name)
color = input("what is your fav color")
animal = input("what is your fav animal")
print("{}, you like a {} {}!".format(name,color,animal))
