import subprocess
command="ps"
commandArgument="-x"
print(f'Gathering active process information with command: {command} {commandArgument}')
x = subprocess.run([command,commandArgument])