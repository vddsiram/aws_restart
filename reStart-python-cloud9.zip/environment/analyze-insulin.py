import re

# Open the file
with open("preproinsulin-seq.txt", "r") as f:
    # Read the contents of the file
    contents = f.read()

# Use regex to remove the "ORIGIN" line, numbers, slashes, spaces, and line breaks
#cleaned_sequence = re.sub("ORIGIN\n\s*\d*\s", "", contents)
cleaned_sequence = re.sub("ORIGIN\s*\d*\s", "", contents)
cleaned_sequence = re.sub("//", "", cleaned_sequence)
cleaned_sequence = re.sub("\n", "", cleaned_sequence)
cleaned_sequence = re.sub("\s", "", cleaned_sequence)
cleaned_sequence = re.sub("\d", "", cleaned_sequence)


# Confirm that the cleaned sequence has 110 characters
assert len(cleaned_sequence) == 110, "The cleaned sequence does not have 110 characters"
print(len(cleaned_sequence))

# Write the cleaned sequence to a new file
with open("preproinsulin-seq-clean.txt", "w") as f:
    f.write(cleaned_sequence)

# Load the cleaned sequence from the file
with open("preproinsulin-seq-clean.txt", "r") as f:
    cleaned_sequence = f.read()

# Extract the desired amino acids for each file
a_sequence = cleaned_sequence[89:110]
b_sequence = cleaned_sequence[24:54]
c_sequence = cleaned_sequence[54:89]
ls_sequence = cleaned_sequence[0:24]

# Save the extracted sequences to separate files
with open("ainsulin-seq.txt", "w") as f:
    f.write(a_sequence)

with open("binsulin-seq.txt", "w") as f:
    f.write(b_sequence)

with open("cinsulin-seq.txt", "w") as f:
    f.write(c_sequence)

with open("lsinsulin-seq.txt", "w") as f:
    f.write(ls_sequence)

# Confirm that each sequence has the correct number of characters
assert len(a_sequence) == 21, "a_sequence does not have 21 characters"
assert len(b_sequence) == 30, "b_sequence does not have 30 characters"
assert len(c_sequence) == 35, "c_sequence does not have 35 characters"
assert len(ls_sequence) == 24, "d_sequence does not have 24 characters"
